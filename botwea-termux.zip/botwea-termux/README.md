### Moshi Moshi~ I'm ANKER<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="27px">

🍙 Help me!

* [Saweria](https://saweria.co/darkbot2412)

#Gopay/Pulsa/Dana:0813-6864-6011

## Tools

```bash
> Termux
> WhatsApp
> 2 HandPhone
```

---

## Information
- Ubah Nama kontak owner [this section](https://github.com/4NK3R-PRODUCT1ON/botwea-termux/blob/main/index.js#L101)
- Ubah Nama Creator [this section](https://github.com/4NK3R-PRODUCT1ON/botwea-termux/blob/main/index.js#L102)
- Ubah Nomer owner [this section](https://github.com/4NK3R-PRODUCT1ON/botwea-termux/blob/main/index.js#L322)
- Ubah prefix [this section](https://github.com/4NK3R-PRODUCT1ON/botwea-termux/blob/main/index.js#L105)
- Ubah apikey Mhank Bar 2x [this section](https://github.com/4NK3R-PRODUCT1ON/botwea-termux/blob/main/index.js#L273)
- Ubah vhtear [this section](https://github.com/4NK3R-PRODUCT1ON/botwea-termux/blob/main/index.js#L275)
- Ubah Nomer Bug Report [this section](https://github.com/4NK3R-PRODUCT1ON/botwea-termux/blob/main/index.js#L5578)

---

- Get BarBarKey on [this site](https://mhankbarbar.tech)
- Get Vhtear on [this site](https://vhtear.com)

---

## Install
Follow The Steps Below!

```bash
> termux-setup-storage
(after that tap on permission)
> apt install git -y
> git clone https://github.com/4NK3R-PRODUCT1ON/botwea-termux
> cd botwea
> bash install.sh


> pkg update && pkg upgrade && pkg install git && pkg install bash && git clone https://github.com/4NK3R-PRODUCT1ON/botwea-termux && cd botwea && bash install.sh && npm start
```

## Usage

```bash
> npm start
```

## Features

CEK SENDIRI GAN

---

#DONE

---

## Special Thanks To

- [Baileys](https://github.com/adiwajshing/Baileys)
- [MHANK BAR BAR](https://github.com/MhankBarBar)
- [ RIZKY ]
- [ ARMAN ]
- [ RENANDO ]
- [ MHANKBARBAR ]
- [ AKBAR ]
- [ ANKER ]
