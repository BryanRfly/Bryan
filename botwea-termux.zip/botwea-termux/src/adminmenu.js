const adminmenu = (prefix) => { 
	return `
╠══✪〘 GROUP 〙✪══
║
╠➥ *${prefix}ban @tagmember*
╠➥ *${prefix}unban @tagmember*
╠➥ *${prefix}spamsms [81273xxxx]*
╠➥ *${prefix}kickall*
╠➥ *${prefix}leave*
╠➥ *${prefix}promote*
╠➥ *${prefix}demote*
╠➥ *${prefix}delete*
╠➥ *${prefix}add 62813xxxxx*
╠➥ *${prefix}kickall*
╠➥ *${prefix}tagall*
╠➥  *${prefix}otagall*
╠➥  *${prefix}otagall2*
╠➥  *${prefix}tagall*
╠➥  *${prefix}setdesc*
╠➥  *${prefix}setname*
╠➥  *${prefix}kick* [tag]
╠➥  *${prefix}kickfast [tag]*
╠➥  *${prefix}add* [628xxx]
╠➥  *${prefix}group* [buka]
╠➥  *${prefix}group* [tutup]
╠➥  *${prefix}linkgc*
╠➥  *${prefix}setpp* [foto kau]
╠➥  *${prefix}groupinfo*
╠➥  *${prefix}tagme*
╠➥  *${prefix}nsfw* [enable/disable]
╠➥  *${prefix}anime* [enable/disable]
╠➥  *${prefix}simih* [enable/disable]
╠➥  *${prefix}welcome* [enable/disable]
╠➥  *${prefix}edotensei*
╠➥  *${prefix}listadmins*
╠➥ *${prefix}ownergrup*
╠➥  *${prefix}ping*
╚═〘 BRYAN BOT 〙`
}
exports.adminmenu = adminmenu