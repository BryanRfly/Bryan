const kerangmenu = (prefix) => { 
	return `
╔══✪〘 KERANG 〙✪══
║
║
╠➥ *${prefix}apakah [optional]*
╠➥ *${prefix}rate [optional]*
╠➥ *${prefix}bisakah [optional]*
╠➥ *${prefix}kapankah [optional]*
╠➥ *${prefix}gantengcek*
╠➥ *${prefix}toxic*
╠➥ *${prefix}cantikcek*
╠➥ *${prefix}persengay*
╠➥ *${prefix}watak*
╠➥ *${prefix}hobby*
╠➥ *${prefix}siapa*
╠➥ *${prefix}gay [@Tagmember]*
╠➥ *${prefix}jelekcek*
╠➥ *${prefix}truth*
╠➥ *${prefix}dare*
║
╚═〘 BRYAN BOT 〙`
}
exports.kerangmenu = kerangmenu