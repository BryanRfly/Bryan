const ownercommand = (prefix) => { 
	return `  
*╭˜”*°•.˜”*°• *Owner Command* •°*”˜.•°*”˜
*║┊:* ⃟ ⃟  ━ೋ๑————๑ೋ━* ⃟ ⃟ *
*║┊:◄✜┢┅ீ͜ৡৢ͜͡✦━━◇━━ீ͜ৡৢ͜͡✦┅┧✜►*
*║┊:*      ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈  
*║┊:*  *[teks]  (R͓̽e͓̽p͓̽l͓̽a͓̽y͓̽ ͓̽g͓̽a͓̽m͓̽b͓̽a͓̽r͓̽)*
*║┊:* *${prefix}𝙨 (R͓̽e͓̽p͓̽l͓̽a͓̽y͓̽ ͓̽g͓̽a͓̽m͓̽b͓̽a͓̽r͓̽)*
*║┊:* *${prefix}t (R͓̽e͓̽p͓̽l͓̽a͓̽y͓̽ ͓̽s͓̽t͓̽i͓̽c͓̽k͓̽e͓̽r͓̽)*
*║┊:* *${prefix}k (T͓̽a͓̽g͓̽ ͓̽M͓̽e͓̽m͓̽b͓̽e͓̽r͓̽)*
*║┊:* *${prefix}pin (Q͓̽u͓̽e͓̽r͓̽y͓̽)*
*║┊:* *${prefix}lo2* [loli]
*║┊:* *${prefix}lo* [loli]
*║┊:* *${prefix}hen* [hentai]
*║┊:* *${prefix}ber* [vtuber]
*║┊:* *${prefix}n* [neko]
*║┊:* *${prefix}w* [waifu]
*║┊:* *${prefix}con* [loli]
*║┊:* *${prefix}kep* [bokip]:v
*║┊:* *${prefix}nim* [rndm]
*║┊:* *${prefix}wf2* [waifu]
*║┊:* *${prefix}ner* [groupner]
*║┊:* *${prefix}b* [ban]
*║┊:* *${prefix}ger* [triggerd]
*║┊:* *${prefix}yk* [ytkomen]
*║┊:* *${prefix}menker* [maker]
*║┊:* *${prefix}fume* [fun]
*║┊:* *${prefix}tem* [other]
*║┊:* *${prefix}med* [media]
*║┊:* *${prefix}nime* [anime]
*║┊:* *${prefix}sfw* [nsfw]
*║┊:* *${prefix}wer* [owner]
*║┊:* *${prefix}min* [admin]
*║┊:* *${prefix}rang* [kerang]
*║┊:* *${prefix}all* [listmenu]
*║┊:* *${prefix}he* [help]
*║┊:*      ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ 
*╚═〘 DARK BOT 〙`
}
exports.ownercommand = ownercommand
