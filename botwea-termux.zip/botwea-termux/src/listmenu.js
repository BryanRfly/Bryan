const listmenu = (prefix) => { 
	return `         
╔══✪〘 OWNER 〙✪══
║
╠➥ *${prefix}block 62858xxxxx*
╠➥ *${prefix}unblock 62858xxxxx*
╠➥ *${prefix}promote @tagmember*
╠➥ *${prefix}demote @tagadmin*
╠➥ *${prefix}bc*
╠➥ *${prefix}leave*
╠➥  *${prefix}bc2*
╠➥  *${prefix}leave*
╠➥  *${prefix}clearall*
╠➥  *${prefix}clone*
╠➥  *${prefix}hidetag*
╠➥  *${prefix}hidetag2*
╠➥  *${prefix}setprefix*
╠➥  *${prefix}unban*
╠➥  *${prefix}ban*
╠➥ *${prefix}runtime*
╠➥ *${prefix}hidetag5*
╠➥ *${prefix}hidetag50*
╠➥ *${prefix}hidetag20*
╠➥ *${prefix}hidetag300*
╠➥ *${prefix}getppbot*
╠➥ *${prefix}bcgc*
╠➥ *${prefix}turnoff*
╠➥  *${prefix}getses*
╠➥  *${prefix}addfoto [reply foto]*
╠➥  *${prefix}getfoto [nama file]*
╠➥  *${prefix}addaudio [reply audio]*
╠➥  *${prefix}getaudio [nama file]*
╠➥  *${prefix}addvideo ,[reply video]*
╠➥  *${prefix}getvideo [nama file]*
╠➥ *${prefix}resetsay*
╠➥ *${prefix}addsay*
╠➥ *${prefix}saylist*
╠➥ *${prefix}addbacot*
╠➥ *${prefix}bacotlist*
╠➥ *${prefix}resetbacot*
╠➥ *${prefix}resetuser*
╠➥ *${prefix}addvip [nomor@s.whatsapp.net]*
╠➥ *${prefix}resetallvipuser*
╠➥  *${prefix}getsticker [teks]*
╠➥  *${prefix}savestick [nama file]*
╠➥  *${prefix}
╠➥ *${prefix}totaluser*
║
╠══✪〘 GROUP 〙✪══
║
╠➥ *${prefix}ban @tagmember*
╠➥ *${prefix}unban @tagmember*
╠➥ *${prefix}spamsms [81273xxxx]*
╠➥ *${prefix}kickall*
╠➥ *${prefix}leave*
╠➥ *${prefix}promote*
╠➥ *${prefix}demote*
╠➥ *${prefix}delete*
╠➥ *${prefix}add 62813xxxxx*
╠➥ *${prefix}kickall*
╠➥ *${prefix}tagall*
╠➥  *${prefix}otagall*
╠➥  *${prefix}otagall2*
╠➥  *${prefix}tagall*
╠➥  *${prefix}getpic [tag]*
╠➥  *${prefix}delete [replay chat bot]*
╠➥  *${prefix}setdesc*
╠➥  *${prefix}setname*
╠➥  *${prefix}kick* [tag]
╠➥  *${prefix}add* [628xxx]
╠➥  *${prefix}group* [buka]
╠➥  *${prefix}group* [tutup]
╠➥  *${prefix}linkgc*
╠➥  *${prefix}setpp* [foto kau]
╠➥  *${prefix}groupinfo*
╠➥  *${prefix}tagme*
╠➥  *${prefix}nsfw* [enable/disable]
╠➥  *${prefix}anime* [enable/disable]
╠➥  *${prefix}simih* [enable/disable]
╠➥  *${prefix}welcome* [enable/disable]
╠➥  *${prefix}antilink* [enable/disable]
╠➥  *${prefix}edotensei*
╠➥  *${prefix}listadmins*
╠➥ *${prefix}ownergrup*
╠➥  *${prefix}ping*
║
╠══✪〘 FUN 〙✪══ 
║
╠➥ *${prefix}tebakgambar*
╠➥ *${prefix}caklontong*
╠➥ *${prefix}family100*
╠➥ *${prefix}quotes* 
╠➥ *${prefix}hilih* 
╠➥ *${prefix}alay* [text] 
╠➥ *${prefix}simi* [text]
╠➥ *${prefix}bucin*
╠➥ *${prefix}tts [kode negara] [teks]*
╠➥ *${prefix}bahasalist*
║
╠══✪〘 KERANG 〙✪══
║
╠➥ *${prefix}apakah [optional]*
╠➥ *${prefix}rate [optional]*
╠➥ *${prefix}bisakah [optional]*
╠➥ *${prefix}kapankah [optional]*
╠➥ *${prefix}gantengcek*
╠➥ *${prefix}toxic*
╠➥ *${prefix}cantikcek*
╠➥ *${prefix}persengay*
╠➥ *${prefix}watak*
╠➥ *${prefix}hobby*
╠➥ *${prefix}siapa*
╠➥ *${prefix}gay [@Tagmember]*
╠➥ *${prefix}jelekcek*
╠➥ *${prefix}truth*
╠➥ *${prefix}dare*
║
╠══✪〘 MAKER 〙✪══ 
║
╠➥ *${prefix}tahta* [iki]
╠➥ *${prefix}pronlogo* [text|text]
╠➥ *${prefix}bpink [teks]* 
╠➥ *${prefix}snow* [text|text] 
╠➥ *${prefix}marvelogo* [text|text] 
╠➥ *${prefix}text3d* [text] 
╠➥ *${prefix}shadow [text]*
╠➥ *${prefix}goldbutton [text]*
╠➥ *${prefix}silverbutton [text]*
╠➥ *${prefix}minion [text]*
╠➥ *${prefix}gaminglogo [text]"
╠➥ *${prefix}ninjalogo* [text|text] 
╠➥ *${prefix}wolflogo* [text|text] 
╠➥ *${prefix}lionlogo* [text|text] 
╠➥ *${prefix}textscreen* [text
╠➥ *${prefix}rtext* [text]
╠➥ *${prefix}thunder* [text] [
╠➥ *${prefix}glaas*
╠➥ *${prefix}triggerd*
╠➥ *${prefix}burning*
╠➥ *${prefix}pelangi*
╠➥ *${prefix}stiltext* [text|text]
╠➥ *${prefix}party* [text]
╠➥ *${prefix}galaxtext* [text]
╠➥ *${prefix}lovemake* [text]
╠➥ *${prefix}walpaperhd* [text]
╠➥ *${prefix}watercolor* [text]
╠➥ *${prefix}quotemaker* [tx|tx|random] 
╠➥ *${prefix}water* [text]
╠➥ *${prefix}epep* [text]
╠➥ *${prefix}glitch* [text]
╠➥ *${prefix}jokerlogo [teks]* 
║
╠══✪〘 MEDIA 〙✪══
║
╠➥ *${prefix}yt* [link]
╠➥ *${prefix}tiktok* [link]
╠➥ *${prefix}ytsearch* [yt search]
╠➥ *${prefix}lirik* [judul lagu]
╠➥ *${prefix}chord* [judul lagu]
╠➥ *${prefix}igstalk* [Rizky]
╠➥ *${prefix}fb [url]*
╠➥ *${prefix}wikien* [love]
╠➥ *${prefix}tiktokstalk* [username]
╠➥ *${prefix}img2url* [reply foto]
╠➥ *${prefix}trendtwit*
╠➥ *${prefix}fototiktok* [username]
╠➥ *${prefix}map* [kota]
╠➥ *${prefix}kbbi* [kamus]
╠➥ *${prefix}brainly [tau sendiri kan]*
╠➥ *${prefix}infoghitub* 
╠➥ *${prefix}neonime
╠➥ *${prefix}cuaca* [kota]
╠➥ *${prefix}infogempa*
╠➥ *${prefix}artinama [nama]*
╠➥ *${prefix}spamcall [82387804410]*
╠➥ *${prefix}covid [negara]*
╠➥ *${prefix}nulis [teks]*
╠➥ *${prefix}sandwriting [teks]*
╠➥ *${prefix}quotemaker [|teks|author|theme]*
╠➥ *${prefix}resepmasakan [optional]*
╠➥ *${prefix}tts [kode bhs] [teks]*
╠➥ *${prefix}igstalk [@username]*
╠➥ *${prefix}tiktokstalk [@username]*
╠➥ *${prefix}Darkjokes*
╠➥ *${prefix}wiki [query]*
╠➥ *${prefix}infonomor [823×××]*
╠➥ *${prefix}slap*
╠➥ *${prefix}xd*
╠➥ *${prefix}aguse*
╠➥ *${prefix}infomobil [namamobil]*
╠➥ *${prefix}infomotor [namamotor]*
╠➥ *${prefix} playstore [nama game]*
╠➥ *${prefix}beritahoax*
╠➥ *${prefix}ramalhp [823×××]*
╠➥ *${prefix}qrcode [optional]*
╠➥ *${prefix}map [optional]*
╠➥ *${prefix}textmaker [teks1|teks2]*
╠➥ *${prefix}ssweb [linkWeb]*
╠➥ *${prefix}shorturl [linkWeb]*
╠➥ *${prefix}quran*
║
╠══✪〘 VIP USER 〙✪══
║
╠➥ *${prefix}ytmp4 [link]*
╠➥ *${prefix}ytmp3 [link]*
╠➥ *${prefix}hidetag2*
╠➥ *${prefix}joox [lagu]*
╠➥ *${prefix}setprefix*
╠➥ *${prefix}tomp3 [replay video]*
╠➥  *${prefix}randomanime*
╠➥  *${prefix}randomhentai*
╠➥  *${prefix}nsfwloli*
╠➥  *${prefix}nsfwblowjob*
╠➥  *${prefix}nsfwneko*
╠➥  *${prefix}nsfwtrap*
╠➥  *${prefix}indohot*
╠➥  *${prefix}fitnah [tag|teks|teks]
╠➥  *${prefix}otagall2*
╠➥  *${prefix}otagall3*
╠➥  *${prefix}asupan*
╠➥  *${prefix}hidetag5*
╠➥ *${prefix}play [lagu]*
║
╰─⊱ *${prefix}indo(1-25)*
╭─⊱ *CONTOH:* *${prefix}indo1*
║
║
╠══✪〘 NSFW 〙✪══
║
╠➥ *${prefix}randomhentai*
╠➥ *${prefix}hentai*
╠➥ *${prefix}nsfwblowjob*
╠➥ *${prefix}nsfwtrap*
╠➥ *${prefix}nsfwneko*
╠➥ *${prefix}loli*
╠➥ *${prefix}nsfwloli*
╠➥ *${prefix}bokep*
╠➥ *${prefix}kodenuklir2*
╠➥ *${prefix}randomanime*
╠➥ *${prefix}cry*
╠➥ *${prefix}cium*
╠➥ *${prefix}tium*
╠➥ *${prefix}animehug*
╠➥ *${prefix}nekonime*
╠➥ *${prefix}waifu*
╠➥ *${prefix}waifu2*
╠➥ *${prefix}kodenuklir*
╠➥ *${prefix}nekopoi*
║
╠══✪〘 ANIME 〙✪══
║
╠➥ *${prefix}randomanime*
╠➥ *${prefix}waifu*
╠➥ *${prefix}waifu2*
╠➥ *${prefix}nekonime*
╠➥ *${prefix}genreanime*
╠➥ *${prefix}animesaran*
╠➥ *${prefix}animesaran2*
╠➥ *${prefix}wibu*
╠➥ *${prefix}wait [foto opening anime]*
╠➥ *${prefix}inu*
╠➥ *${prefix}pokemon*
╠➥ *${prefix}naruto*
╠➥ *${prefix}ranime*
╠➥ *${prefix}hinata*
╠➥ *${prefix}sasuke*
╠➥ *${prefix}sakura*
╠➥ *${prefix}boruto*
╠➥ *${prefix}minato*
╠➥ *${prefix}loli*
╠➥ *${prefix}loli2*
╠➥ *${prefix}rize*
╠➥ *${prefix}akira*
╠➥ *${prefix}husbu*
╠➥ *${prefix}itori*
╠➥ *${prefix}animehappy*
╠➥ *${prefix}kurumi*
╠➥ *${prefix}animesad*
╠➥ *${prefix}miku*
║
╠══✪〘 OTHER 〙✪══
║
╠➥ *${prefix}sticker*
╠➥ *${prefix}nobg*
╠➥  *${prefix}stickergif*
╠➥  *${prefix}jomblo*
╠➥  *${prefix}bitly [link]*
╠➥ *${prefix}kodenegara*
╠➥ *${prefix}hurufjepang*
╠➥ *${prefix}hurufkatakanajepang*
╠➥ *${prefix}walpaper*
╠➥ *${prefix}readmore [teks|teks]*
╠➥ *${prefix}baper*
╠➥ *${prefix}stickergif*
╠➥ *${prefix}ttp [teks]*
╠➥ *${prefix}toimg [replay sticker]*
╠➥ *${prefix}neko*
╠➥ *${prefix}pokemon*
╠➥ *${prefix}inu*
╠➥ *${prefix}infoGempa*
╠➥ *${prefix}quotes*
╠➥ *${prefix}dadu*
╠➥ *${prefix}wame*
╠➥ *${prefix}quotes*
╠➥ *${prefix}aesthetic*
╠➥ *${prefix}thunder [teks]*
╠➥ *${prefix}nulis [teks]*
╠➥ *${prefix}ocr [gambar]*
╠➥ *${prefix}meme*
╠➥ *${prefix}memindo*
╠➥ *${prefix}testime*
╠➥ *${prefix}ttp [teks]*
╠➥ *${prefix}hobby*
╠➥ *${prefix}beritahoax*
╠➥ *${prefix}watak*
╠➥ *${prefix}jsholat [daerah]*
╠➥ *${prefix}report*
╠➥ *${prefix}hilih [teks]*
╠➥ *${prefix}cekjodoh* [nama]
╠➥ *${prefix}artinama* [rizky]
╠➥ *${prefix}listsurah*
╠➥ *${prefix}zodiak [zodiak kamu]*
╠➥ *${prefix}listzodiak*
╠➥ *${prefix}koin*
╠➥ *${prefix}say*
╠➥ *${prefix}bacot*
╠➥ *${prefix}reminder [waktu|kegiatan]*
╠➥ *${prefix}ytkomen [nama|teks]*
║
╠═══✪〘 ANIMALS 〙✪══
║
╠➥ *${prefix}unta*
╠➥ *${prefix}elang*
╠➥ *${prefix}anjing*
╠➥ *${prefix}randomcat*
║
╠═══✪〘 PICT MENU 〙✪══
║
╰─⊱ *PictMenu*
|─⊱ *${prefix}cowok*
|─⊱ *${prefix}cewek*
|─⊱ *${prefix}lolicon*
|─⊱ *${prefix}waifu*
|─⊱ *${prefix}neko*
|─⊱ *${prefix}hewan*
|─⊱ *${prefix}vtuber*
╭─⊱ *CONTOH:* *${prefix}pictcowok*
║
╚═ Ketik *${prefix}info* untuk melihat list informasi tentang bot
       Ketik *${prefix}owner* untuk melihat kontak owner
         Mau donasi? 081368646011(GOPAY/PULSA/DANA)
         Jika tidak ingin donasi bantu Follow Ig aja kak 
         _instagram.com/anker_2412
    _*BRYAN BOT © 2021*_`
}
exports.listmenu = listmenu