const help = (prefix) => { 
	return `
╭══─⊱  ⸨ 𝐼𝑁𝐹𝑂 ⸩  ⊰─══╮
║
┣╾⊱ *BRYAN BOT*
┣╾⊱ *9.0*
┣╾⊱ *VERSION : TERMUX*
┣╾⊱ *wa.me/6281368646011*
┣╾⊱ *THANKS TO :*
┣━━━━[ *AKBAR* ]━━━━━
┣━━━━[ *ARMAN* ]━━━━
┣━━━━[ *RIZKY* ]━━━━━
┣━━━━[ *ANKER* ]━━━━━
║
╰══─⊱  ⸨ ANKER ⸩  ⊰─══╯
            𝐑𝐮𝐥𝐞𝐬 - 𝐒𝐢𝐦𝐩𝐥𝐞
▬▭▬▭▬▭▬▭▬▭▬▭▬
●⧐ *Spam : Auto Block!*
  ●⧐ *Beri Jeda 5detik Saat Menggunakannya!!*
    ●⧐ *Bug/Error Harap Cht Owner!*
    ●⧐ *Untuk Memastikan Bot Off Atau On*
    ●⧐ *Ketik ${prefix}bot*
  ●⧐ *Harap Sabar Dengan Bug²nya!*
●⧐ *Gunakan Bot Sebaik-baiknya!*
▬▭▬▭▬▭▬▭▬▭▬▭▬
               𝐁𝐲 - 𝐑𝐢𝐳𝐤𝐲
               
▣═─⊱【 𝐿𝐼𝑆𝑇 𝑀𝐸𝑁𝑈 】⊰─══
║
╰─⊱ Menu Simple aja Ya Terlalu Banyak Spam Hehe:D
╭─⊱ ♥
  |─⊱ *${prefix}listmenu*
╰─⊱ ♥
╭─⊱ Mau masukin Bot kegrup?Ketik *${prefix}iklan* ya kak:D
║
▣═══─⊱【 𝑂𝑇𝐻𝐸𝑅 】⊰─═══
║
╰─⊱ *${prefix}request [teksmu*
╭─⊱ *${prefix}setprefix*
  |─⊱ *${prefix}bugreport [teksmu]*
  |─⊱ *${prefix}listblock*
  |─⊱ *${prefix}iklan*
  |─⊱ *${prefix}runtime*
  |─⊱ *${prefix}info*
  |─⊱ *${prefix}rules*
  |─⊱ *${prefix}tnc*
  |─⊱ *${prefix}totaluser*
  |─⊱ *${prefix}banlist*
  |─⊱ *${prefix}premiumlist*
  |─⊱ *${prefix}daftar*
  |─⊱ *${prefix}cekvip*
  |─⊱ *${prefix}daftarvip*
  |─⊱ *${prefix}addvip*
  |─⊱ *${prefix}dellvip*
  |─⊱ *${prefix}snk*
  |─⊱ *${prefix}BRYANadmin*
  |─⊱ *${prefix}BRYANgroup*
  |─⊱ *${prefix}listpremium*
  |─⊱ *${prefix}donate*
╰─⊱ *${prefix}ping*
╭─⊱ *${prefix}owner*
║
▣══─⊱ 【 𝑅𝑈𝑁𝑇𝐼𝑀𝐸 】 ⊰─══
║
╰─⊱ *STATUS BOT: Online*
╭─⊱ BOT ON: *TERGANTUNG OWNER*
║
▣══─ ⸨ BRYAN 𝘽𝙊𝙏𝙒𝘼 ⸩ ─══▣`
}
exports.help = help
